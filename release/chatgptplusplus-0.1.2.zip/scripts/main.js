"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!globalThis.chrome?.runtime?.id) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = /* @__PURE__ */ __name((extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            __name(DefaultWeakMap, "DefaultWeakMap");
            const isThenable = /* @__PURE__ */ __name((value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            }, "isThenable");
            const makeCallback = /* @__PURE__ */ __name((promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            }, "makeCallback");
            const pluralizeArguments = /* @__PURE__ */ __name((numArgs) => numArgs == 1 ? "argument" : "arguments", "pluralizeArguments");
            const wrapAsyncFunction = /* @__PURE__ */ __name((name, metadata) => {
              return /* @__PURE__ */ __name(function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              }, "asyncFunctionWrapper");
            }, "wrapAsyncFunction");
            const wrapMethod = /* @__PURE__ */ __name((target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            }, "wrapMethod");
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = /* @__PURE__ */ __name((target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            }, "wrapObject");
            const wrapEvent = /* @__PURE__ */ __name((wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            }), "wrapEvent");
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return /* @__PURE__ */ __name(function onRequestFinished(req) {
                const wrappedReq = wrapObject(
                  req,
                  {},
                  {
                    getContent: {
                      minArgs: 0,
                      maxArgs: 0
                    }
                  }
                );
                listener(wrappedReq);
              }, "onRequestFinished");
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return /* @__PURE__ */ __name(function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = /* @__PURE__ */ __name(function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  }, "wrappedSendResponse");
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = /* @__PURE__ */ __name((promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                }, "sendPromisedResult");
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              }, "onMessage");
            });
            const wrappedSendMessageCallback = /* @__PURE__ */ __name(({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            }, "wrappedSendMessageCallback");
            const wrappedSendMessage = /* @__PURE__ */ __name((name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            }, "wrappedSendMessage");
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          }, "wrapAPIs");
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // node_modules/preact/dist/preact.module.js
  var n, l, u, i, t, r, o, f, e, c = {}, s = [], a = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  function h(n2, l3) {
    for (var u3 in l3)
      n2[u3] = l3[u3];
    return n2;
  }
  __name(h, "h");
  function v(n2) {
    var l3 = n2.parentNode;
    l3 && l3.removeChild(n2);
  }
  __name(v, "v");
  function y(l3, u3, i3) {
    var t3, r3, o4, f3 = {};
    for (o4 in u3)
      "key" == o4 ? t3 = u3[o4] : "ref" == o4 ? r3 = u3[o4] : f3[o4] = u3[o4];
    if (arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), "function" == typeof l3 && null != l3.defaultProps)
      for (o4 in l3.defaultProps)
        void 0 === f3[o4] && (f3[o4] = l3.defaultProps[o4]);
    return p(l3, f3, t3, r3, null);
  }
  __name(y, "y");
  function p(n2, i3, t3, r3, o4) {
    var f3 = { type: n2, props: i3, key: t3, ref: r3, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: null == o4 ? ++u : o4 };
    return null == o4 && null != l.vnode && l.vnode(f3), f3;
  }
  __name(p, "p");
  function d() {
    return { current: null };
  }
  __name(d, "d");
  function _(n2) {
    return n2.children;
  }
  __name(_, "_");
  function k(n2, l3) {
    this.props = n2, this.context = l3;
  }
  __name(k, "k");
  function b(n2, l3) {
    if (null == l3)
      return n2.__ ? b(n2.__, n2.__.__k.indexOf(n2) + 1) : null;
    for (var u3; l3 < n2.__k.length; l3++)
      if (null != (u3 = n2.__k[l3]) && null != u3.__e)
        return u3.__e;
    return "function" == typeof n2.type ? b(n2) : null;
  }
  __name(b, "b");
  function g(n2) {
    var l3, u3;
    if (null != (n2 = n2.__) && null != n2.__c) {
      for (n2.__e = n2.__c.base = null, l3 = 0; l3 < n2.__k.length; l3++)
        if (null != (u3 = n2.__k[l3]) && null != u3.__e) {
          n2.__e = n2.__c.base = u3.__e;
          break;
        }
      return g(n2);
    }
  }
  __name(g, "g");
  function m(n2) {
    (!n2.__d && (n2.__d = true) && t.push(n2) && !w.__r++ || r !== l.debounceRendering) && ((r = l.debounceRendering) || o)(w);
  }
  __name(m, "m");
  function w() {
    var n2, l3, u3, i3, r3, o4, e3, c3;
    for (t.sort(f); n2 = t.shift(); )
      n2.__d && (l3 = t.length, i3 = void 0, r3 = void 0, e3 = (o4 = (u3 = n2).__v).__e, (c3 = u3.__P) && (i3 = [], (r3 = h({}, o4)).__v = o4.__v + 1, L(c3, o4, r3, u3.__n, void 0 !== c3.ownerSVGElement, null != o4.__h ? [e3] : null, i3, null == e3 ? b(o4) : e3, o4.__h), M(i3, o4), o4.__e != e3 && g(o4)), t.length > l3 && t.sort(f));
    w.__r = 0;
  }
  __name(w, "w");
  function x(n2, l3, u3, i3, t3, r3, o4, f3, e3, a3) {
    var h3, v3, y3, d3, k3, g3, m3, w3 = i3 && i3.__k || s, x3 = w3.length;
    for (u3.__k = [], h3 = 0; h3 < l3.length; h3++)
      if (null != (d3 = u3.__k[h3] = null == (d3 = l3[h3]) || "boolean" == typeof d3 || "function" == typeof d3 ? null : "string" == typeof d3 || "number" == typeof d3 || "bigint" == typeof d3 ? p(null, d3, null, null, d3) : Array.isArray(d3) ? p(_, { children: d3 }, null, null, null) : d3.__b > 0 ? p(d3.type, d3.props, d3.key, d3.ref ? d3.ref : null, d3.__v) : d3)) {
        if (d3.__ = u3, d3.__b = u3.__b + 1, null === (y3 = w3[h3]) || y3 && d3.key == y3.key && d3.type === y3.type)
          w3[h3] = void 0;
        else
          for (v3 = 0; v3 < x3; v3++) {
            if ((y3 = w3[v3]) && d3.key == y3.key && d3.type === y3.type) {
              w3[v3] = void 0;
              break;
            }
            y3 = null;
          }
        L(n2, d3, y3 = y3 || c, t3, r3, o4, f3, e3, a3), k3 = d3.__e, (v3 = d3.ref) && y3.ref != v3 && (m3 || (m3 = []), y3.ref && m3.push(y3.ref, null, d3), m3.push(v3, d3.__c || k3, d3)), null != k3 ? (null == g3 && (g3 = k3), "function" == typeof d3.type && d3.__k === y3.__k ? d3.__d = e3 = A(d3, e3, n2) : e3 = C(n2, d3, y3, w3, k3, e3), "function" == typeof u3.type && (u3.__d = e3)) : e3 && y3.__e == e3 && e3.parentNode != n2 && (e3 = b(y3));
      }
    for (u3.__e = g3, h3 = x3; h3--; )
      null != w3[h3] && ("function" == typeof u3.type && null != w3[h3].__e && w3[h3].__e == u3.__d && (u3.__d = $(i3).nextSibling), S(w3[h3], w3[h3]));
    if (m3)
      for (h3 = 0; h3 < m3.length; h3++)
        O(m3[h3], m3[++h3], m3[++h3]);
  }
  __name(x, "x");
  function A(n2, l3, u3) {
    for (var i3, t3 = n2.__k, r3 = 0; t3 && r3 < t3.length; r3++)
      (i3 = t3[r3]) && (i3.__ = n2, l3 = "function" == typeof i3.type ? A(i3, l3, u3) : C(u3, i3, i3, t3, i3.__e, l3));
    return l3;
  }
  __name(A, "A");
  function P(n2, l3) {
    return l3 = l3 || [], null == n2 || "boolean" == typeof n2 || (Array.isArray(n2) ? n2.some(function(n3) {
      P(n3, l3);
    }) : l3.push(n2)), l3;
  }
  __name(P, "P");
  function C(n2, l3, u3, i3, t3, r3) {
    var o4, f3, e3;
    if (void 0 !== l3.__d)
      o4 = l3.__d, l3.__d = void 0;
    else if (null == u3 || t3 != r3 || null == t3.parentNode)
      n:
        if (null == r3 || r3.parentNode !== n2)
          n2.appendChild(t3), o4 = null;
        else {
          for (f3 = r3, e3 = 0; (f3 = f3.nextSibling) && e3 < i3.length; e3 += 1)
            if (f3 == t3)
              break n;
          n2.insertBefore(t3, r3), o4 = r3;
        }
    return void 0 !== o4 ? o4 : t3.nextSibling;
  }
  __name(C, "C");
  function $(n2) {
    var l3, u3, i3;
    if (null == n2.type || "string" == typeof n2.type)
      return n2.__e;
    if (n2.__k) {
      for (l3 = n2.__k.length - 1; l3 >= 0; l3--)
        if ((u3 = n2.__k[l3]) && (i3 = $(u3)))
          return i3;
    }
    return null;
  }
  __name($, "$");
  function H(n2, l3, u3, i3, t3) {
    var r3;
    for (r3 in u3)
      "children" === r3 || "key" === r3 || r3 in l3 || T(n2, r3, null, u3[r3], i3);
    for (r3 in l3)
      t3 && "function" != typeof l3[r3] || "children" === r3 || "key" === r3 || "value" === r3 || "checked" === r3 || u3[r3] === l3[r3] || T(n2, r3, l3[r3], u3[r3], i3);
  }
  __name(H, "H");
  function I(n2, l3, u3) {
    "-" === l3[0] ? n2.setProperty(l3, null == u3 ? "" : u3) : n2[l3] = null == u3 ? "" : "number" != typeof u3 || a.test(l3) ? u3 : u3 + "px";
  }
  __name(I, "I");
  function T(n2, l3, u3, i3, t3) {
    var r3;
    n:
      if ("style" === l3)
        if ("string" == typeof u3)
          n2.style.cssText = u3;
        else {
          if ("string" == typeof i3 && (n2.style.cssText = i3 = ""), i3)
            for (l3 in i3)
              u3 && l3 in u3 || I(n2.style, l3, "");
          if (u3)
            for (l3 in u3)
              i3 && u3[l3] === i3[l3] || I(n2.style, l3, u3[l3]);
        }
      else if ("o" === l3[0] && "n" === l3[1])
        r3 = l3 !== (l3 = l3.replace(/Capture$/, "")), l3 = l3.toLowerCase() in n2 ? l3.toLowerCase().slice(2) : l3.slice(2), n2.l || (n2.l = {}), n2.l[l3 + r3] = u3, u3 ? i3 || n2.addEventListener(l3, r3 ? z : j, r3) : n2.removeEventListener(l3, r3 ? z : j, r3);
      else if ("dangerouslySetInnerHTML" !== l3) {
        if (t3)
          l3 = l3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("width" !== l3 && "height" !== l3 && "href" !== l3 && "list" !== l3 && "form" !== l3 && "tabIndex" !== l3 && "download" !== l3 && l3 in n2)
          try {
            n2[l3] = null == u3 ? "" : u3;
            break n;
          } catch (n3) {
          }
        "function" == typeof u3 || (null == u3 || false === u3 && -1 == l3.indexOf("-") ? n2.removeAttribute(l3) : n2.setAttribute(l3, u3));
      }
  }
  __name(T, "T");
  function j(n2) {
    return this.l[n2.type + false](l.event ? l.event(n2) : n2);
  }
  __name(j, "j");
  function z(n2) {
    return this.l[n2.type + true](l.event ? l.event(n2) : n2);
  }
  __name(z, "z");
  function L(n2, u3, i3, t3, r3, o4, f3, e3, c3) {
    var s3, a3, v3, y3, p3, d3, b3, g3, m3, w3, A3, P3, C2, $2, H2, I2 = u3.type;
    if (void 0 !== u3.constructor)
      return null;
    null != i3.__h && (c3 = i3.__h, e3 = u3.__e = i3.__e, u3.__h = null, o4 = [e3]), (s3 = l.__b) && s3(u3);
    try {
      n:
        if ("function" == typeof I2) {
          if (g3 = u3.props, m3 = (s3 = I2.contextType) && t3[s3.__c], w3 = s3 ? m3 ? m3.props.value : s3.__ : t3, i3.__c ? b3 = (a3 = u3.__c = i3.__c).__ = a3.__E : ("prototype" in I2 && I2.prototype.render ? u3.__c = a3 = new I2(g3, w3) : (u3.__c = a3 = new k(g3, w3), a3.constructor = I2, a3.render = q), m3 && m3.sub(a3), a3.props = g3, a3.state || (a3.state = {}), a3.context = w3, a3.__n = t3, v3 = a3.__d = true, a3.__h = [], a3._sb = []), null == a3.__s && (a3.__s = a3.state), null != I2.getDerivedStateFromProps && (a3.__s == a3.state && (a3.__s = h({}, a3.__s)), h(a3.__s, I2.getDerivedStateFromProps(g3, a3.__s))), y3 = a3.props, p3 = a3.state, a3.__v = u3, v3)
            null == I2.getDerivedStateFromProps && null != a3.componentWillMount && a3.componentWillMount(), null != a3.componentDidMount && a3.__h.push(a3.componentDidMount);
          else {
            if (null == I2.getDerivedStateFromProps && g3 !== y3 && null != a3.componentWillReceiveProps && a3.componentWillReceiveProps(g3, w3), !a3.__e && null != a3.shouldComponentUpdate && false === a3.shouldComponentUpdate(g3, a3.__s, w3) || u3.__v === i3.__v) {
              for (u3.__v !== i3.__v && (a3.props = g3, a3.state = a3.__s, a3.__d = false), a3.__e = false, u3.__e = i3.__e, u3.__k = i3.__k, u3.__k.forEach(function(n3) {
                n3 && (n3.__ = u3);
              }), A3 = 0; A3 < a3._sb.length; A3++)
                a3.__h.push(a3._sb[A3]);
              a3._sb = [], a3.__h.length && f3.push(a3);
              break n;
            }
            null != a3.componentWillUpdate && a3.componentWillUpdate(g3, a3.__s, w3), null != a3.componentDidUpdate && a3.__h.push(function() {
              a3.componentDidUpdate(y3, p3, d3);
            });
          }
          if (a3.context = w3, a3.props = g3, a3.__P = n2, P3 = l.__r, C2 = 0, "prototype" in I2 && I2.prototype.render) {
            for (a3.state = a3.__s, a3.__d = false, P3 && P3(u3), s3 = a3.render(a3.props, a3.state, a3.context), $2 = 0; $2 < a3._sb.length; $2++)
              a3.__h.push(a3._sb[$2]);
            a3._sb = [];
          } else
            do {
              a3.__d = false, P3 && P3(u3), s3 = a3.render(a3.props, a3.state, a3.context), a3.state = a3.__s;
            } while (a3.__d && ++C2 < 25);
          a3.state = a3.__s, null != a3.getChildContext && (t3 = h(h({}, t3), a3.getChildContext())), v3 || null == a3.getSnapshotBeforeUpdate || (d3 = a3.getSnapshotBeforeUpdate(y3, p3)), H2 = null != s3 && s3.type === _ && null == s3.key ? s3.props.children : s3, x(n2, Array.isArray(H2) ? H2 : [H2], u3, i3, t3, r3, o4, f3, e3, c3), a3.base = u3.__e, u3.__h = null, a3.__h.length && f3.push(a3), b3 && (a3.__E = a3.__ = null), a3.__e = false;
        } else
          null == o4 && u3.__v === i3.__v ? (u3.__k = i3.__k, u3.__e = i3.__e) : u3.__e = N(i3.__e, u3, i3, t3, r3, o4, f3, c3);
      (s3 = l.diffed) && s3(u3);
    } catch (n3) {
      u3.__v = null, (c3 || null != o4) && (u3.__e = e3, u3.__h = !!c3, o4[o4.indexOf(e3)] = null), l.__e(n3, u3, i3);
    }
  }
  __name(L, "L");
  function M(n2, u3) {
    l.__c && l.__c(u3, n2), n2.some(function(u4) {
      try {
        n2 = u4.__h, u4.__h = [], n2.some(function(n3) {
          n3.call(u4);
        });
      } catch (n3) {
        l.__e(n3, u4.__v);
      }
    });
  }
  __name(M, "M");
  function N(l3, u3, i3, t3, r3, o4, f3, e3) {
    var s3, a3, h3, y3 = i3.props, p3 = u3.props, d3 = u3.type, _4 = 0;
    if ("svg" === d3 && (r3 = true), null != o4) {
      for (; _4 < o4.length; _4++)
        if ((s3 = o4[_4]) && "setAttribute" in s3 == !!d3 && (d3 ? s3.localName === d3 : 3 === s3.nodeType)) {
          l3 = s3, o4[_4] = null;
          break;
        }
    }
    if (null == l3) {
      if (null === d3)
        return document.createTextNode(p3);
      l3 = r3 ? document.createElementNS("http://www.w3.org/2000/svg", d3) : document.createElement(d3, p3.is && p3), o4 = null, e3 = false;
    }
    if (null === d3)
      y3 === p3 || e3 && l3.data === p3 || (l3.data = p3);
    else {
      if (o4 = o4 && n.call(l3.childNodes), a3 = (y3 = i3.props || c).dangerouslySetInnerHTML, h3 = p3.dangerouslySetInnerHTML, !e3) {
        if (null != o4)
          for (y3 = {}, _4 = 0; _4 < l3.attributes.length; _4++)
            y3[l3.attributes[_4].name] = l3.attributes[_4].value;
        (h3 || a3) && (h3 && (a3 && h3.__html == a3.__html || h3.__html === l3.innerHTML) || (l3.innerHTML = h3 && h3.__html || ""));
      }
      if (H(l3, p3, y3, r3, e3), h3)
        u3.__k = [];
      else if (_4 = u3.props.children, x(l3, Array.isArray(_4) ? _4 : [_4], u3, i3, t3, r3 && "foreignObject" !== d3, o4, f3, o4 ? o4[0] : i3.__k && b(i3, 0), e3), null != o4)
        for (_4 = o4.length; _4--; )
          null != o4[_4] && v(o4[_4]);
      e3 || ("value" in p3 && void 0 !== (_4 = p3.value) && (_4 !== l3.value || "progress" === d3 && !_4 || "option" === d3 && _4 !== y3.value) && T(l3, "value", _4, y3.value, false), "checked" in p3 && void 0 !== (_4 = p3.checked) && _4 !== l3.checked && T(l3, "checked", _4, y3.checked, false));
    }
    return l3;
  }
  __name(N, "N");
  function O(n2, u3, i3) {
    try {
      "function" == typeof n2 ? n2(u3) : n2.current = u3;
    } catch (n3) {
      l.__e(n3, i3);
    }
  }
  __name(O, "O");
  function S(n2, u3, i3) {
    var t3, r3;
    if (l.unmount && l.unmount(n2), (t3 = n2.ref) && (t3.current && t3.current !== n2.__e || O(t3, null, u3)), null != (t3 = n2.__c)) {
      if (t3.componentWillUnmount)
        try {
          t3.componentWillUnmount();
        } catch (n3) {
          l.__e(n3, u3);
        }
      t3.base = t3.__P = null, n2.__c = void 0;
    }
    if (t3 = n2.__k)
      for (r3 = 0; r3 < t3.length; r3++)
        t3[r3] && S(t3[r3], u3, i3 || "function" != typeof n2.type);
    i3 || null == n2.__e || v(n2.__e), n2.__ = n2.__e = n2.__d = void 0;
  }
  __name(S, "S");
  function q(n2, l3, u3) {
    return this.constructor(n2, u3);
  }
  __name(q, "q");
  function B(u3, i3, t3) {
    var r3, o4, f3;
    l.__ && l.__(u3, i3), o4 = (r3 = "function" == typeof t3) ? null : t3 && t3.__k || i3.__k, f3 = [], L(i3, u3 = (!r3 && t3 || i3).__k = y(_, null, [u3]), o4 || c, c, void 0 !== i3.ownerSVGElement, !r3 && t3 ? [t3] : o4 ? null : i3.firstChild ? n.call(i3.childNodes) : null, f3, !r3 && t3 ? t3 : o4 ? o4.__e : i3.firstChild, r3), M(f3, u3);
  }
  __name(B, "B");
  function D(n2, l3) {
    B(n2, l3, D);
  }
  __name(D, "D");
  function E(l3, u3, i3) {
    var t3, r3, o4, f3 = h({}, l3.props);
    for (o4 in u3)
      "key" == o4 ? t3 = u3[o4] : "ref" == o4 ? r3 = u3[o4] : f3[o4] = u3[o4];
    return arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), p(l3.type, f3, t3 || l3.key, r3 || l3.ref, null);
  }
  __name(E, "E");
  function F(n2, l3) {
    var u3 = { __c: l3 = "__cC" + e++, __: n2, Consumer: function(n3, l4) {
      return n3.children(l4);
    }, Provider: function(n3) {
      var u4, i3;
      return this.getChildContext || (u4 = [], (i3 = {})[l3] = this, this.getChildContext = function() {
        return i3;
      }, this.shouldComponentUpdate = function(n4) {
        this.props.value !== n4.value && u4.some(function(n5) {
          n5.__e = true, m(n5);
        });
      }, this.sub = function(n4) {
        u4.push(n4);
        var l4 = n4.componentWillUnmount;
        n4.componentWillUnmount = function() {
          u4.splice(u4.indexOf(n4), 1), l4 && l4.call(n4);
        };
      }), n3.children;
    } };
    return u3.Provider.__ = u3.Consumer.contextType = u3;
  }
  __name(F, "F");
  n = s.slice, l = { __e: function(n2, l3, u3, i3) {
    for (var t3, r3, o4; l3 = l3.__; )
      if ((t3 = l3.__c) && !t3.__)
        try {
          if ((r3 = t3.constructor) && null != r3.getDerivedStateFromError && (t3.setState(r3.getDerivedStateFromError(n2)), o4 = t3.__d), null != t3.componentDidCatch && (t3.componentDidCatch(n2, i3 || {}), o4 = t3.__d), o4)
            return t3.__E = t3;
        } catch (l4) {
          n2 = l4;
        }
    throw n2;
  } }, u = 0, i = /* @__PURE__ */ __name(function(n2) {
    return null != n2 && void 0 === n2.constructor;
  }, "i"), k.prototype.setState = function(n2, l3) {
    var u3;
    u3 = null != this.__s && this.__s !== this.state ? this.__s : this.__s = h({}, this.state), "function" == typeof n2 && (n2 = n2(h({}, u3), this.props)), n2 && h(u3, n2), null != n2 && this.__v && (l3 && this._sb.push(l3), m(this));
  }, k.prototype.forceUpdate = function(n2) {
    this.__v && (this.__e = true, n2 && this.__h.push(n2), m(this));
  }, k.prototype.render = _, t = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, f = /* @__PURE__ */ __name(function(n2, l3) {
    return n2.__v.__b - l3.__v.__b;
  }, "f"), w.__r = 0, e = 0;

  // node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
  var _2 = 0;
  function o2(o4, e3, n2, t3, f3, l3) {
    var s3, u3, a3 = {};
    for (u3 in e3)
      "ref" == u3 ? s3 = e3[u3] : a3[u3] = e3[u3];
    var i3 = { type: o4, props: a3, key: n2, ref: s3, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: --_2, __source: f3, __self: l3 };
    if ("function" == typeof o4 && (s3 = o4.defaultProps))
      for (u3 in s3)
        void 0 === a3[u3] && (a3[u3] = s3[u3]);
    return l.vnode && l.vnode(i3), i3;
  }
  __name(o2, "o");

  // src/assets/svg.tsx
  var svg_default = {
    modification() {
      return /* @__PURE__ */ o2("svg", { stroke: "currentColor", fill: "none", "stroke-width": "2", viewBox: "0 0 24 24", strokeLinecap: "round", strokeLinejoin: "round", class: "h-4 w-4", height: "1em", width: "1em", xmlns: "http://www.w3.org/2000/svg", children: [
        /* @__PURE__ */ o2("path", { d: "M12 20h9" }),
        /* @__PURE__ */ o2("path", { d: "M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" })
      ] });
    },
    trashcan() {
      return /* @__PURE__ */ o2("svg", { stroke: "currentColor", fill: "none", "stroke-width": "2", viewBox: "0 0 24 24", "stroke-linecap": "round", "stroke-linejoin": "round", class: "h-4 w-4", height: "1em", width: "1em", xmlns: "http://www.w3.org/2000/svg", children: [
        /* @__PURE__ */ o2("polyline", { points: "3 6 5 6 21 6" }),
        /* @__PURE__ */ o2("path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" }),
        /* @__PURE__ */ o2("line", { x1: "10", y1: "11", x2: "10", y2: "17" }),
        /* @__PURE__ */ o2("line", { x1: "14", y1: "11", x2: "14", y2: "17" })
      ] });
    },
    visible() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", children: /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5s5 2.24 5 5s-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3s3-1.34 3-3s-1.34-3-3-3z" }) });
    },
    invisible() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 1024 1024", children: [
        /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M508 624a112 112 0 0 0 112-112c0-3.28-.15-6.53-.43-9.74L498.26 623.57c3.21.28 6.45.43 9.74.43zm370.72-458.44L836 122.88a8 8 0 0 0-11.31 0L715.37 232.23Q624.91 186 512 186q-288.3 0-430.2 300.3a60.3 60.3 0 0 0 0 51.5q56.7 119.43 136.55 191.45L112.56 835a8 8 0 0 0 0 11.31L155.25 889a8 8 0 0 0 11.31 0l712.16-712.12a8 8 0 0 0 0-11.32zM332 512a176 176 0 0 1 258.88-155.28l-48.62 48.62a112.08 112.08 0 0 0-140.92 140.92l-48.62 48.62A175.09 175.09 0 0 1 332 512z" }),
        /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M942.2 486.2Q889.4 375 816.51 304.85L672.37 449A176.08 176.08 0 0 1 445 676.37L322.74 798.63Q407.82 838 512 838q288.3 0 430.2-300.3a60.29 60.29 0 0 0 0-51.5z" })
      ] });
    },
    questionMark() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", class: "text-gray-900 dark:text-gray-200", children: /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M12.025 16q-.6 0-1.012-.425t-.363-1q.075-1.05.5-1.825t1.35-1.6q1.025-.9 1.563-1.563t.537-1.512q0-1.025-.687-1.7T12 5.7q-.8 0-1.363.338t-.912.837q-.35.5-.862.675t-.988-.025q-.575-.25-.787-.825t.087-1.075Q7.9 4.5 9.125 3.75T12 3q2.625 0 4.038 1.462t1.412 3.513q0 1.25-.537 2.138t-1.688 2.012q-.85.8-1.2 1.3t-.475 1.15q-.1.625-.525 1.025t-1 .4ZM12 22q-.825 0-1.413-.588T10 20q0-.825.588-1.413T12 18q.825 0 1.413.588T14 20q0 .825-.588 1.413T12 22Z" }) });
    },
    crossMark() {
      return /* @__PURE__ */ o2("svg", { stroke: "currentColor", fill: "none", "stroke-width": "2", viewBox: "0 0 24 24", "stroke-linecap": "round", "stroke-linejoin": "round", class: "text-gray-900 dark:text-gray-200", height: "20", width: "20", xmlns: "http://www.w3.org/2000/svg", children: [
        /* @__PURE__ */ o2("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
        /* @__PURE__ */ o2("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
      ] });
    },
    plusMark() {
      return /* @__PURE__ */ o2("svg", { stroke: "currentColor", fill: "none", "stroke-width": "2", viewBox: "0 0 24 24", "stroke-linecap": "round", "stroke-linejoin": "round", class: "h-4 w-4", height: "1em", width: "1em", xmlns: "http://www.w3.org/2000/svg", children: [
        /* @__PURE__ */ o2("line", { x1: "12", y1: "5", x2: "12", y2: "19" }),
        /* @__PURE__ */ o2("line", { x1: "5", y1: "12", x2: "19", y2: "12" })
      ] });
    },
    instruction() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", class: "text-gray-900 dark:text-gray-200", children: [
        /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M11 14.17L8.83 12L11 9.83L9.59 8.41L6 12l3.59 3.59zm3.41 1.42L18 12l-3.59-3.59L13 9.83L15.17 12L13 14.17z" }),
        /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M19 3h-4.18C14.4 1.84 13.3 1 12 1s-2.4.84-2.82 2H5c-.14 0-.27.01-.4.04a2.008 2.008 0 0 0-1.44 1.19c-.1.23-.16.49-.16.77v14c0 .27.06.54.16.78s.25.45.43.64c.27.27.62.47 1.01.55c.13.02.26.03.4.03h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7-.25c.41 0 .75.34.75.75s-.34.75-.75.75s-.75-.34-.75-.75s.34-.75.75-.75zM19 15v4H5V5h14v10z" })
      ] });
    },
    settings() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", children: /* @__PURE__ */ o2("path", { fill: "currentColor", d: "m9.25 22l-.4-3.2q-.325-.125-.613-.3t-.562-.375L4.7 19.375l-2.75-4.75l2.575-1.95Q4.5 12.5 4.5 12.337v-.674q0-.163.025-.338L1.95 9.375l2.75-4.75l2.975 1.25q.275-.2.575-.375t.6-.3l.4-3.2h5.5l.4 3.2q.325.125.613.3t.562.375l2.975-1.25l2.75 4.75l-2.575 1.95q.025.175.025.338v.674q0 .163-.05.338l2.575 1.95l-2.75 4.75l-2.95-1.25q-.275.2-.575.375t-.6.3l-.4 3.2h-5.5Zm2.8-6.5q1.45 0 2.475-1.025T15.55 12q0-1.45-1.025-2.475T12.05 8.5q-1.475 0-2.488 1.025T8.55 12q0 1.45 1.012 2.475T12.05 15.5Z" }) });
    },
    gears() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 640 512", children: /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M308.5 135.3c7.1-6.3 9.9-16.2 6.2-25c-2.3-5.3-4.8-10.5-7.6-15.5l-3.1-5.4c-3-5-6.3-9.9-9.8-14.6c-5.7-7.6-15.7-10.1-24.7-7.1L241.3 77c-10.7-8.8-23-16-36.2-20.9l-6.1-29c-1.9-9.3-9.1-16.7-18.5-17.8c-6.6-.9-13.3-1.3-20.1-1.3h-.7c-6.8 0-13.5.4-20.1 1.2c-9.4 1.1-16.6 8.6-18.5 17.8L115 56.1c-13.3 5-25.5 12.1-36.2 20.9l-28.3-9.2c-9-3-19-.5-24.7 7.1c-3.5 4.7-6.8 9.6-9.9 14.6l-3 5.3c-2.8 5-5.3 10.2-7.6 15.6c-3.7 8.7-.9 18.6 6.2 25l22.2 19.8c-1.1 6.7-1.7 13.7-1.7 20.8s.6 14.1 1.7 20.9l-22.2 19.8c-7.1 6.3-9.9 16.2-6.2 25c2.3 5.3 4.8 10.5 7.6 15.6l3 5.2c3 5.1 6.3 9.9 9.9 14.6c5.7 7.6 15.7 10.1 24.7 7.1l28.2-9.3c10.7 8.8 23 16 36.2 20.9l6.1 29.1c1.9 9.3 9.1 16.7 18.5 17.8c6.7.8 13.5 1.2 20.4 1.2s13.7-.4 20.4-1.2c9.4-1.1 16.6-8.6 18.5-17.8l6.1-29.1c13.3-5 25.5-12.1 36.2-20.9l28.2 9.3c9 3 19 .5 24.7-7.1c3.5-4.7 6.8-9.5 9.8-14.6l3.1-5.4c2.8-5 5.3-10.2 7.6-15.5c3.7-8.7.9-18.6-6.2-25l-22.2-19.8c1.1-6.8 1.7-13.8 1.7-20.9s-.6-14.1-1.7-20.9l22.2-19.8zM112 176a48 48 0 1 1 96 0a48 48 0 1 1-96 0zm392.7 324.5c6.3 7.1 16.2 9.9 25 6.2c5.3-2.3 10.5-4.8 15.5-7.6l5.4-3.1c5-3 9.9-6.3 14.6-9.8c7.6-5.7 10.1-15.7 7.1-24.7l-9.3-28.2c8.8-10.7 16-23 20.9-36.2L613 391c9.3-1.9 16.7-9.1 17.8-18.5c.8-6.7 1.2-13.5 1.2-20.4s-.4-13.7-1.2-20.4c-1.1-9.4-8.6-16.6-17.8-18.5l-29.1-6.2c-5-13.3-12.1-25.5-20.9-36.2l9.3-28.2c3-9 .5-19-7.1-24.7c-4.7-3.5-9.6-6.8-14.6-9.9l-5.3-3c-5-2.8-10.2-5.3-15.6-7.6c-8.7-3.7-18.6-.9-25 6.2l-19.8 22.2c-6.8-1.1-13.8-1.7-20.9-1.7s-14.1.6-20.9 1.7l-19.8-22.2c-6.3-7.1-16.2-9.9-25-6.2c-5.3 2.3-10.5 4.8-15.6 7.6l-5.2 3c-5.1 3-9.9 6.3-14.6 9.9c-7.6 5.7-10.1 15.7-7.1 24.7l9.3 28.2c-8.8 10.7-16 23-20.9 36.2l-29.1 6c-9.3 1.9-16.7 9.1-17.8 18.5c-.8 6.7-1.2 13.5-1.2 20.4s.4 13.7 1.2 20.4c1.1 9.4 8.6 16.6 17.8 18.5l29.1 6.1c5 13.3 12.1 25.5 20.9 36.2l-9.3 28.2c-3 9-.5 19 7.1 24.7c4.7 3.5 9.5 6.8 14.6 9.8l5.4 3.1c5 2.8 10.2 5.3 15.5 7.6c8.7 3.7 18.6.9 25-6.2l19.8-22.2c6.8 1.1 13.8 1.7 20.9 1.7s14.1-.6 20.9-1.7l19.8 22.2zM464 304a48 48 0 1 1 0 96a48 48 0 1 1 0-96z" }) });
    },
    arrowDown() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", children: /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M12 14.975q-.2 0-.388-.075t-.312-.2l-4.6-4.6q-.275-.275-.275-.7t.275-.7q.275-.275.7-.275t.7.275l3.9 3.9l3.9-3.9q.275-.275.7-.275t.7.275q.275.275.275.7t-.275.7l-4.6 4.6q-.15.15-.325.213t-.375.062Z" }) });
    },
    arrowUp() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", children: /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M6.7 14.7q-.275-.275-.275-.7t.275-.7l4.6-4.6q.15-.15.325-.212T12 8.425q.2 0 .388.075t.312.2l4.6 4.6q.275.275.275.7t-.275.7q-.275.275-.7.275t-.7-.275L12 10.8l-3.9 3.9q-.275.275-.7.275t-.7-.275Z" }) });
    },
    restore() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", children: /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M13 3a9 9 0 0 0-9 9H1l3.89 3.89l.07.14L9 12H6a7 7 0 0 1 7-7a7 7 0 0 1 7 7a7 7 0 0 1-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.896 8.896 0 0 0 13 21a9 9 0 0 0 9-9a9 9 0 0 0-9-9Z" }) });
    },
    preview() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", children: /* @__PURE__ */ o2("path", { fill: "currentColor", d: "M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2m-7 0a1 1 0 0 1 1 1a1 1 0 0 1-1 1a1 1 0 0 1-1-1a1 1 0 0 1 1-1M7 7h10V5h2v14H5V5h2v2Z" }) });
    },
    community() {
      return /* @__PURE__ */ o2("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", children: /* @__PURE__ */ o2("g", { fill: "none", stroke: "currentColor", "stroke-linecap": "round", "stroke-linejoin": "round", "stroke-width": "2", children: [
        /* @__PURE__ */ o2("path", { d: "M21 12a9 9 0 1 0-9 9M3.6 9h16.8M3.6 15h7.9" }),
        /* @__PURE__ */ o2("path", { d: "M11.5 3a17 17 0 0 0 0 18m1-18a16.984 16.984 0 0 1 2.574 8.62M15 18a3 3 0 1 0 6 0a3 3 0 1 0-6 0m5.2 2.2L22 22" })
      ] }) });
    }
  };

  // node_modules/preact/hooks/dist/hooks.module.js
  var t2, r2, u2, i2, o3 = 0, f2 = [], c2 = [], e2 = l.__b, a2 = l.__r, v2 = l.diffed, l2 = l.__c, m2 = l.unmount;
  function d2(t3, u3) {
    l.__h && l.__h(r2, t3, o3 || u3), o3 = 0;
    var i3 = r2.__H || (r2.__H = { __: [], __h: [] });
    return t3 >= i3.__.length && i3.__.push({ __V: c2 }), i3.__[t3];
  }
  __name(d2, "d");
  function h2(n2) {
    return o3 = 1, s2(B2, n2);
  }
  __name(h2, "h");
  function s2(n2, u3, i3) {
    var o4 = d2(t2++, 2);
    if (o4.t = n2, !o4.__c && (o4.__ = [i3 ? i3(u3) : B2(void 0, u3), function(n3) {
      var t3 = o4.__N ? o4.__N[0] : o4.__[0], r3 = o4.t(t3, n3);
      t3 !== r3 && (o4.__N = [r3, o4.__[1]], o4.__c.setState({}));
    }], o4.__c = r2, !r2.u)) {
      var f3 = /* @__PURE__ */ __name(function(n3, t3, r3) {
        if (!o4.__c.__H)
          return true;
        var u4 = o4.__c.__H.__.filter(function(n4) {
          return n4.__c;
        });
        if (u4.every(function(n4) {
          return !n4.__N;
        }))
          return !c3 || c3.call(this, n3, t3, r3);
        var i4 = false;
        return u4.forEach(function(n4) {
          if (n4.__N) {
            var t4 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t4 !== n4.__[0] && (i4 = true);
          }
        }), !(!i4 && o4.__c.props === n3) && (!c3 || c3.call(this, n3, t3, r3));
      }, "f");
      r2.u = true;
      var c3 = r2.shouldComponentUpdate, e3 = r2.componentWillUpdate;
      r2.componentWillUpdate = function(n3, t3, r3) {
        if (this.__e) {
          var u4 = c3;
          c3 = void 0, f3(n3, t3, r3), c3 = u4;
        }
        e3 && e3.call(this, n3, t3, r3);
      }, r2.shouldComponentUpdate = f3;
    }
    return o4.__N || o4.__;
  }
  __name(s2, "s");
  function p2(u3, i3) {
    var o4 = d2(t2++, 3);
    !l.__s && z2(o4.__H, i3) && (o4.__ = u3, o4.i = i3, r2.__H.__h.push(o4));
  }
  __name(p2, "p");
  function y2(u3, i3) {
    var o4 = d2(t2++, 4);
    !l.__s && z2(o4.__H, i3) && (o4.__ = u3, o4.i = i3, r2.__h.push(o4));
  }
  __name(y2, "y");
  function _3(n2) {
    return o3 = 5, F2(function() {
      return { current: n2 };
    }, []);
  }
  __name(_3, "_");
  function A2(n2, t3, r3) {
    o3 = 6, y2(function() {
      return "function" == typeof n2 ? (n2(t3()), function() {
        return n2(null);
      }) : n2 ? (n2.current = t3(), function() {
        return n2.current = null;
      }) : void 0;
    }, null == r3 ? r3 : r3.concat(n2));
  }
  __name(A2, "A");
  function F2(n2, r3) {
    var u3 = d2(t2++, 7);
    return z2(u3.__H, r3) ? (u3.__V = n2(), u3.i = r3, u3.__h = n2, u3.__V) : u3.__;
  }
  __name(F2, "F");
  function T2(n2, t3) {
    return o3 = 8, F2(function() {
      return n2;
    }, t3);
  }
  __name(T2, "T");
  function q2(n2) {
    var u3 = r2.context[n2.__c], i3 = d2(t2++, 9);
    return i3.c = n2, u3 ? (null == i3.__ && (i3.__ = true, u3.sub(r2)), u3.props.value) : n2.__;
  }
  __name(q2, "q");
  function x2(t3, r3) {
    l.useDebugValue && l.useDebugValue(r3 ? r3(t3) : t3);
  }
  __name(x2, "x");
  function P2(n2) {
    var u3 = d2(t2++, 10), i3 = h2();
    return u3.__ = n2, r2.componentDidCatch || (r2.componentDidCatch = function(n3, t3) {
      u3.__ && u3.__(n3, t3), i3[1](n3);
    }), [i3[0], function() {
      i3[1](void 0);
    }];
  }
  __name(P2, "P");
  function V() {
    var n2 = d2(t2++, 11);
    if (!n2.__) {
      for (var u3 = r2.__v; null !== u3 && !u3.__m && null !== u3.__; )
        u3 = u3.__;
      var i3 = u3.__m || (u3.__m = [0, 0]);
      n2.__ = "P" + i3[0] + "-" + i3[1]++;
    }
    return n2.__;
  }
  __name(V, "V");
  function b2() {
    for (var t3; t3 = f2.shift(); )
      if (t3.__P && t3.__H)
        try {
          t3.__H.__h.forEach(k2), t3.__H.__h.forEach(w2), t3.__H.__h = [];
        } catch (r3) {
          t3.__H.__h = [], l.__e(r3, t3.__v);
        }
  }
  __name(b2, "b");
  l.__b = function(n2) {
    r2 = null, e2 && e2(n2);
  }, l.__r = function(n2) {
    a2 && a2(n2), t2 = 0;
    var i3 = (r2 = n2.__c).__H;
    i3 && (u2 === r2 ? (i3.__h = [], r2.__h = [], i3.__.forEach(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.__V = c2, n3.__N = n3.i = void 0;
    })) : (i3.__h.forEach(k2), i3.__h.forEach(w2), i3.__h = [])), u2 = r2;
  }, l.diffed = function(t3) {
    v2 && v2(t3);
    var o4 = t3.__c;
    o4 && o4.__H && (o4.__H.__h.length && (1 !== f2.push(o4) && i2 === l.requestAnimationFrame || ((i2 = l.requestAnimationFrame) || j2)(b2)), o4.__H.__.forEach(function(n2) {
      n2.i && (n2.__H = n2.i), n2.__V !== c2 && (n2.__ = n2.__V), n2.i = void 0, n2.__V = c2;
    })), u2 = r2 = null;
  }, l.__c = function(t3, r3) {
    r3.some(function(t4) {
      try {
        t4.__h.forEach(k2), t4.__h = t4.__h.filter(function(n2) {
          return !n2.__ || w2(n2);
        });
      } catch (u3) {
        r3.some(function(n2) {
          n2.__h && (n2.__h = []);
        }), r3 = [], l.__e(u3, t4.__v);
      }
    }), l2 && l2(t3, r3);
  }, l.unmount = function(t3) {
    m2 && m2(t3);
    var r3, u3 = t3.__c;
    u3 && u3.__H && (u3.__H.__.forEach(function(n2) {
      try {
        k2(n2);
      } catch (n3) {
        r3 = n3;
      }
    }), u3.__H = void 0, r3 && l.__e(r3, u3.__v));
  };
  var g2 = "function" == typeof requestAnimationFrame;
  function j2(n2) {
    var t3, r3 = /* @__PURE__ */ __name(function() {
      clearTimeout(u3), g2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, "r"), u3 = setTimeout(r3, 100);
    g2 && (t3 = requestAnimationFrame(r3));
  }
  __name(j2, "j");
  function k2(n2) {
    var t3 = r2, u3 = n2.__c;
    "function" == typeof u3 && (n2.__c = void 0, u3()), r2 = t3;
  }
  __name(k2, "k");
  function w2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  __name(w2, "w");
  function z2(n2, t3) {
    return !n2 || n2.length !== t3.length || t3.some(function(t4, r3) {
      return t4 !== n2[r3];
    });
  }
  __name(z2, "z");
  function B2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }
  __name(B2, "B");

  // src/hooks/booleanContext.tsx
  var BooleanContext = F({
    bool: 0,
    setBool: () => null,
    toggle: () => null
  });
  var BooleanProvider = /* @__PURE__ */ __name(({ children }) => {
    const [bool, setBool] = h2(0);
    function toggle() {
      setBool(bool ? 0 : 1);
    }
    __name(toggle, "toggle");
    const value = F2(() => {
      return { bool, setBool, toggle };
    }, [bool]);
    return /* @__PURE__ */ o2(BooleanContext.Provider, { value, children });
  }, "BooleanProvider");
  var useBoolean = /* @__PURE__ */ __name(() => {
    const { bool, setBool, toggle } = q2(BooleanContext);
    return { bool, setBool, toggle };
  }, "useBoolean");

  // src/components/base/toggleButton.tsx
  function ToggleButton(props) {
    const { toggle } = useBoolean();
    const defaultClass = "flex justify-center items-center dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-900 rounded-md";
    const className = `${defaultClass} ${props?.className}`;
    const innerElement = typeof props?.innerText === "string" ? /* @__PURE__ */ o2("span", { children: props.innerText }) : props.innerText;
    return /* @__PURE__ */ o2("button", { onClick: toggle, style: props?.style, className, children: innerElement });
  }
  __name(ToggleButton, "ToggleButton");

  // src/utils/storage.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  async function readSyncedStorage(obj) {
    return await import_webextension_polyfill.default.storage.sync.get(obj);
  }
  __name(readSyncedStorage, "readSyncedStorage");
  async function persistSyncedStorage(obj) {
    await import_webextension_polyfill.default.storage.sync.set(obj);
  }
  __name(persistSyncedStorage, "persistSyncedStorage");
  async function testRemoveSyncedStorage(obj) {
    await import_webextension_polyfill.default.storage.sync.remove(obj);
  }
  __name(testRemoveSyncedStorage, "testRemoveSyncedStorage");

  // src/managers/userConfig.ts
  var defaultUserConfig = {
    cppTemperature: 1,
    cppTemperatureEnabled: false,
    cppMaxTokens: 2048,
    cppMaxTokensEnabled: false,
    cppPromptID: "default",
    cppPresencePenalty: 0,
    cppPresencePenaltyEnabled: false,
    cppFrequencyPenalty: 0,
    cppFrequencyPenaltyEnabled: false,
    cppLanguage: "English",
    cppLanguageEnabled: false
    //TODO: make UI/model for logit_bias, best_of, n, logprobs(what even is this?)
  };
  async function getUserConfig() {
    const config = await readSyncedStorage(Object.keys(defaultUserConfig));
    if (!config)
      return defaultUserConfig;
    return config;
  }
  __name(getUserConfig, "getUserConfig");
  async function saveUserConfig(config) {
    await persistSyncedStorage(config);
  }
  __name(saveUserConfig, "saveUserConfig");

  // src/components/base/cppDialog.tsx
  function DialogTitle(props) {
    return /* @__PURE__ */ o2("div", { className: "flex w-full flex-row items-center justify-between border-b py-3 px-4 dark:border-gray-700", children: [
      props?.title && /* @__PURE__ */ o2("span", { class: "text-base font-semibold sm:text-base", children: props.title }),
      /* @__PURE__ */ o2("button", { className: "text-gray-700 opacity-50 transition hover:opacity-75 dark:text-white", onClick: props.closeDialog, children: /* @__PURE__ */ o2(svg_default.crossMark, {}) })
    ] });
  }
  __name(DialogTitle, "DialogTitle");
  var dialogStates = {};
  function Dialog(props) {
    function closeDialog() {
      props.setVisible(false);
    }
    __name(closeDialog, "closeDialog");
    function clickOutside() {
      if (typeof props.closeOnClickOutside === "function" && props.closeOnClickOutside())
        closeDialog();
      else if (typeof props.closeOnClickOutside === "boolean" && props.closeOnClickOutside)
        closeDialog();
    }
    __name(clickOutside, "clickOutside");
    p2(() => {
      if (props.onVisibleChange)
        props.onVisibleChange(props.isVisible);
    }, [props.isVisible]);
    return /* @__PURE__ */ o2(_, { children: props.isVisible && /* @__PURE__ */ o2("div", { className: "relative", style: { zIndex: 500 }, children: [
      /* @__PURE__ */ o2("div", { className: "fixed w-full h-full inset-0 bg-gray-500/90 transition-opacity dark:bg-gray-800/90 opacity-100", style: { zIndex: 510 } }),
      /* @__PURE__ */ o2("div", { className: "fixed inset-0 overflow-y-auto", style: { zIndex: 520 }, onClick: clickOutside, children: /* @__PURE__ */ o2("div", { className: "flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0 !p-0", children: /* @__PURE__ */ o2(
        "div",
        {
          className: "relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all dark:bg-gray-900 sm:my-8 sm:w-full !my-0 flex min-h-screen w-full flex-col items-center justify-center !rounded-none !py-0 px-4 pt-5 pb-4 sm:p-6 bg-transparent dark:bg-transparent opacity-100 translate-y-0 sm:scale-100",
          style: { zIndex: 530 },
          children: /* @__PURE__ */ o2("div", { className: "flex h-full flex-col items-center justify-start", children: /* @__PURE__ */ o2("div", { className: "relative", children: /* @__PURE__ */ o2("div", { className: "grow justify-center bg-white dark:bg-gray-900 rounded-md flex flex-col items-start overflow-hidden border shadow-md dark:border-gray-700", children: [
            /* @__PURE__ */ o2(DialogTitle, { closeDialog, title: props.title }),
            props.body
          ] }) }) })
        }
      ) }) })
    ] }) });
  }
  __name(Dialog, "Dialog");
  function getDialogRoot() {
    let cppDialogRoot = document.querySelector("#cpp-dialog-root");
    if (!cppDialogRoot) {
      cppDialogRoot = document.createElement("div");
      cppDialogRoot.id = "cpp-dialog-root";
      cppDialogRoot.className = "";
      cppDialogRoot.style.zIndex = "500";
      document.body.appendChild(cppDialogRoot);
    }
    return cppDialogRoot;
  }
  __name(getDialogRoot, "getDialogRoot");
  function checkVisibility() {
    const cppDialogRoot = getDialogRoot();
    if (!cppDialogRoot)
      return;
    let shouldShow = true;
    for (const k3 in dialogStates) {
      if (dialogStates[k3].isVisible)
        continue;
      shouldShow = false;
      break;
    }
    cppDialogRoot.style.display = shouldShow ? "" : "none";
  }
  __name(checkVisibility, "checkVisibility");
  function useDialogState(namespace) {
    const [isVisible, setVisible] = h2(false);
    dialogStates[namespace] = { isVisible, setVisible };
    p2(() => {
      checkVisibility();
    }, [isVisible]);
    return { isVisible, setVisible };
  }
  __name(useDialogState, "useDialogState");
  function CppDialog(props) {
    const cppDialogRoot = getDialogRoot();
    const { isVisible, setVisible } = useDialogState(props.namespace);
    const onVisibleChangeRef = _3();
    function onVisibilityChange(isVisible2) {
      if (onVisibleChangeRef.current)
        onVisibleChangeRef.current(isVisible2);
    }
    __name(onVisibilityChange, "onVisibilityChange");
    function openDialog() {
      setVisible(true);
    }
    __name(openDialog, "openDialog");
    p2(() => {
      if (!cppDialogRoot || !cppDialogRoot?.childNodes || !cppDialogRoot?.childNodes?.length) {
        B(/* @__PURE__ */ o2(
          Dialog,
          {
            namespace: props.namespace,
            isVisible,
            setVisible,
            onVisibleChange: (cb) => onVisibilityChange(cb),
            title: props.title,
            body: props.children,
            closeOnClickOutside: props.closeOnClickOutside
          }
        ), cppDialogRoot);
      } else {
        onVisibilityChange(isVisible);
      }
    });
    return /* @__PURE__ */ o2("button", { onClick: openDialog, children: props.buttonText });
  }
  __name(CppDialog, "CppDialog");

  // src/components/base/slider.tsx
  function Slider(props) {
    const [disabled, setDisabled] = h2(props?.enabled !== void 0 ? !props.enabled : false);
    p2(() => {
      setDisabled(props?.enabled !== void 0 ? !props.enabled : false);
    }, [props?.enabled]);
    const onChange = props.onChange ? props.onChange : (e3) => {
      const value = Number(e3.target.value);
      props.context.setValue(value);
    };
    const containerDefaultClass = "flex flex-col items-center w-full";
    const containerClassName = `${containerDefaultClass} ${props?.containerClassName}`;
    const inputDefaultClass = "h-1 w-full rounded-full bg-gray-300 outline-none appearance-none";
    const inputClassName = `${inputDefaultClass} ${props?.inputClassName ? props.inputClassName : ""}`;
    const defaultInputStyle = {};
    const inputStyle = Object.assign({}, defaultInputStyle, props?.inputStyle);
    let ticks = null;
    if (props.tickLabels) {
      const labels = [];
      for (let i3 = 0; i3 < props.tickLabels.length; i3++) {
        labels.push(/* @__PURE__ */ o2("span", { className: "pointer-events-none select-none", children: props.tickLabels[i3] }));
      }
      ticks = /* @__PURE__ */ o2("div", { className: "flex mt-1 justify-between w-full text-sm", children: labels });
    }
    return /* @__PURE__ */ o2("div", { className: containerClassName, style: props?.containerStyle, children: [
      /* @__PURE__ */ o2("input", { type: "range", min: props.min, max: props.max, step: props?.step, value: props.context.value, onChange, className: inputClassName, style: inputStyle, disabled }),
      ticks
    ] });
  }
  __name(Slider, "Slider");

  // src/components/base/dropdown.tsx
  function Dropdown(props) {
    const defaultClass = "shadow-sm px-4 pr-8 sm:text-sm focus:outline-none border border-black/10 bg-white dark:border-gray-900/50 dark:text-white dark:bg-gray-700 rounded-md shadow-[0_0_10px_rgba(0,0,0,0.10)] dark:shadow-[0_0_15px_rgba(0,0,0,0.10)]";
    const className = `${defaultClass} ${props?.className}`;
    const defaultStyle = {};
    const ContainerStyle = Object.assign({}, defaultStyle, props.style ? props.style : {});
    return /* @__PURE__ */ o2("div", { className: "relative block", children: /* @__PURE__ */ o2("select", { className, style: ContainerStyle, value: props.value, onChange: props.onChange, disabled: props.disabled, children: props.options.map(({ value, label }) => /* @__PURE__ */ o2("option", { value, children: label }, value)) }) });
  }
  __name(Dropdown, "Dropdown");

  // src/components/base/contitionalPopup.tsx
  function ConditionalPopup(props) {
    const isShow = useBoolean();
    const defaultStyle = { display: isShow.bool ? "flex" : "none" };
    const style = Object.assign({}, defaultStyle, props?.style);
    const defaultClass = "";
    const className = `${props?.className} ${defaultClass}`;
    return /* @__PURE__ */ o2("div", { style, className, children: props.children });
  }
  __name(ConditionalPopup, "ConditionalPopup");

  // src/components/base/hoverBox.tsx
  function HoverBox(props) {
    const hover = useBoolean();
    const onMouseEnter = /* @__PURE__ */ __name(() => {
      if (!hover.bool)
        hover.setBool(1);
    }, "onMouseEnter");
    const onMouseOver = /* @__PURE__ */ __name(() => {
      if (!hover.bool)
        hover.setBool(1);
    }, "onMouseOver");
    const onMouseLeave = /* @__PURE__ */ __name(() => {
      if (hover.bool)
        hover.setBool(0);
    }, "onMouseLeave");
    const containerDefaultClassName = `flex select-none items-center mr-2`;
    const ContainerClassName = `${props?.className ? props.className : ""} ${hover ? "hover" : "not-hover"} ${containerDefaultClassName}`;
    const popup = hover.bool ? props.children : null;
    return /* @__PURE__ */ o2(_, { children: [
      /* @__PURE__ */ o2("div", { className: ContainerClassName, style: props.style, onMouseEnter, onMouseLeave, onMouseOver, children: props.hoverElement }),
      popup
    ] });
  }
  __name(HoverBox, "HoverBox");
  var hoverBox_default = HoverBox;

  // src/components/base/inputBox.tsx
  function InputBox(props) {
    const onChange = props?.onChange ? props.onChange : (e3) => {
      let value = props.type == "checkbox" ? !!e3.target.checked : e3.target.value;
      props.context.setValue(value);
    };
    const disabled = props?.enabled !== void 0 ? !props.enabled : false;
    const defaultInputClassName = `p-0 text-sm text-gray-900 ${disabled ? "bg-gray-100 dark:bg-gray-600" : ""}`;
    const InputClassName = `${defaultInputClassName} ${props.inputClassName}`;
    const defaultLabelClassName = "ml-1 text-sm";
    const LabelClassName = `${defaultLabelClassName} ${props.labelClassName}`;
    const step = props.step ? props.step : "";
    function disablePropagation(e3) {
      if (e3.key !== "Enter")
        return;
      e3.preventDefault();
    }
    __name(disablePropagation, "disablePropagation");
    return /* @__PURE__ */ o2("div", { children: [
      /* @__PURE__ */ o2("input", { type: props.type, min: props.min, max: props.max, step, value: props.context.value, checked: props.context.value, onChange, onKeyDownCapture: disablePropagation, className: InputClassName, style: props.inputStyle, disabled }),
      /* @__PURE__ */ o2("label", { className: LabelClassName, style: props.labelStyle, children: props.labelText })
    ] });
  }
  __name(InputBox, "InputBox");

  // src/utils/common.ts
  function shallowCompare(A3, B3) {
    return Object.keys(A3).length === Object.keys(B3).length && Object.keys(A3).every((key) => {
      return Object.prototype.hasOwnProperty.call(B3, key) && A3[key] === B3[key];
    });
  }
  __name(shallowCompare, "shallowCompare");
  function deepCopy(obj) {
    return JSON.parse(JSON.stringify(obj));
  }
  __name(deepCopy, "deepCopy");
  function uuidv4() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c3) => {
      const charCode = parseInt(c3);
      return ((charCode ^ crypto.getRandomValues(new Uint8Array(1))[0]) & 15 >> charCode / 4).toString(16);
    });
  }
  __name(uuidv4, "uuidv4");

  // src/managers/prompt.ts
  var defaultPromptSetting = {
    cppSelectedPromptID: "default"
  };
  async function readPromptSetting() {
    const setting = await readSyncedStorage(Object.keys(defaultPromptSetting));
    if (!setting)
      return defaultPromptSetting;
    return setting;
  }
  __name(readPromptSetting, "readPromptSetting");
  async function persistPromptSetting(setting) {
    await persistSyncedStorage(setting);
  }
  __name(persistPromptSetting, "persistPromptSetting");
  var defaultPrompt = {
    id: "default",
    name: "Default",
    body: "",
    pattern: "{&temperature}{&max_tokens}{&presence_penalty}{&frequency_penalty}{$hide_param}{&prompt}{&message}{&language}",
    showOnToolbar: true,
    timecreated: ""
  };
  var getPromptTemplate = /* @__PURE__ */ __name(() => {
    const id = uuidv4();
    return {
      id,
      name: id,
      body: "",
      pattern: defaultPrompt.pattern,
      showOnToolbar: true,
      timecreated: (/* @__PURE__ */ new Date()).toISOString()
    };
  }, "getPromptTemplate");
  async function readPromptList() {
    const raw = await readSyncedStorage("cppPrompt");
    if (!raw || !raw.cppPrompt)
      return {};
    return raw.cppPrompt;
  }
  __name(readPromptList, "readPromptList");
  async function persistPromptList(list) {
    delete list.default;
    const record = { cppPrompt: list };
    await persistSyncedStorage(record);
  }
  __name(persistPromptList, "persistPromptList");
  async function readPrompt(id) {
    if (id === defaultPrompt.id)
      return defaultPrompt;
    const list = await readPromptList();
    return list[id];
  }
  __name(readPrompt, "readPrompt");
  async function persistPrompt(prompt) {
    if (prompt.id === defaultPrompt.id)
      return;
    const list = await readPromptList();
    list[prompt.id] = prompt;
    await persistPromptList(list);
  }
  __name(persistPrompt, "persistPrompt");
  async function destroyPrompt(id) {
    const list = await readPromptList();
    delete list[id];
    await persistPromptList(list);
    return list;
  }
  __name(destroyPrompt, "destroyPrompt");
  var keywords = {
    hide_param: "{$hide_param}",
    temperature: "{&temperature}",
    max_tokens: "{&max_tokens}",
    presence_penalty: "{&presence_penalty}",
    frequency_penalty: "{&frequency_penalty}",
    prompt: "{&prompt}",
    message: "{&message}",
    language: "{&language}"
  };
  async function resolvePattern(prompt, message) {
    const userConfig = await readSyncedStorage(Object.keys(defaultUserConfig));
    const isParameterSetAny = userConfig.cppTemperatureEnabled || userConfig.cppMaxTokensEnabled || userConfig.cppPresencePenaltyEnabled || userConfig.cppFrequencyPenaltyEnabled;
    const mapping = {
      [keywords.hide_param]: isParameterSetAny ? "Don't explain about parameters I set.\n" : "",
      [keywords.temperature]: userConfig.cppTemperatureEnabled ? `temperature ${userConfig.cppTemperature} ` : "",
      [keywords.max_tokens]: userConfig.cppMaxTokensEnabled ? `max_tokens ${userConfig.cppMaxTokens} ` : "",
      [keywords.presence_penalty]: userConfig.cppPresencePenaltyEnabled ? `presence_penalty ${userConfig.cppPresencePenalty} ` : "",
      [keywords.frequency_penalty]: userConfig.cppFrequencyPenaltyEnabled ? `frequency_penalty ${userConfig.cppFrequencyPenalty} ` : "",
      [keywords.language]: userConfig.cppLanguageEnabled ? `
in ${userConfig.cppLanguage}` : "",
      [keywords.prompt]: prompt.body ? `
${prompt.body}` : "",
      [keywords.message]: message ? message : keywords.message
    };
    return Object.keys(mapping).reduce((str, keyword) => {
      return str.replaceAll(keyword, mapping[keyword]);
    }, prompt.pattern);
  }
  __name(resolvePattern, "resolvePattern");
  function sortBytimeCreated(a3, b3) {
    const defaultComesFirst = -1;
    return (new Date(a3.timecreated).getTime() || defaultComesFirst) - (new Date(b3.timecreated).getTime() || defaultComesFirst);
  }
  __name(sortBytimeCreated, "sortBytimeCreated");
  var languages_list = [
    "Afrikaans",
    "Albanian",
    "Amharic",
    "Arabic",
    "Aragonese",
    "Armenian",
    "Asturian",
    "Azerbaijani",
    "Basque",
    "Belarusian",
    "Bengali",
    "Bosnian",
    "Breton",
    "Bulgarian",
    "Catalan",
    "Central Kurdish",
    "Chinese",
    "Chinese (Hong Kong)",
    "Chinese (Simplified)",
    "Chinese (Traditional)",
    "Corsican",
    "Croatian",
    "Czech",
    "Danish",
    "Dutch",
    "English",
    "English (Australia)",
    "English (Canada)",
    "English (India)",
    "English (New Zealand)",
    "English (South Africa)",
    "English (United Kingdom)",
    "English (United States)",
    "Esperanto",
    "Estonian",
    "Faroese",
    "Filipino",
    "Finnish",
    "French",
    "French (Canada)",
    "French (France)",
    "French (Switzerland)",
    "Galician",
    "Georgian",
    "German",
    "German (Austria)",
    "German (Germany)",
    "German (Liechtenstein)",
    "German (Switzerland)",
    "Greek",
    "Guarani",
    "Gujarati",
    "Hausa",
    "Hawaiian",
    "Hebrew",
    "Hindi",
    "Hungarian",
    "Icelandic",
    "Indonesian",
    "Interlingua",
    "Irish",
    "Italian",
    "Italian (Italy)",
    "Italian (Switzerland)",
    "Japanese",
    "Kannada",
    "Kazakh",
    "Khmer",
    "Korean",
    "Kurdish",
    "Kyrgyz",
    "Lao",
    "Latin",
    "Latvian",
    "Lingala",
    "Lithuanian",
    "Macedonian",
    "Malay",
    "Malayalam",
    "Maltese",
    "Marathi",
    "Mongolian",
    "Nepali",
    "Norwegian",
    "Norwegian Bokm\xE5l",
    "Norwegian Nynorsk",
    "Occitan",
    "Oriya",
    "Oromo",
    "Pashto",
    "Persian",
    "Polish",
    "Portuguese",
    "Portuguese (Brazil)",
    "Portuguese (Portugal)",
    "Punjabi",
    "Quechua",
    "Romanian",
    "Romanian (Moldova)",
    "Romansh",
    "Russian",
    "Scottish Gaelic",
    "Serbian",
    "Serbo",
    "Shona",
    "Sindhi",
    "Sinhala",
    "Slovak",
    "Slovenian",
    "Somali",
    "Southern Sotho",
    "Spanish",
    "Spanish (Argentina)",
    "Spanish (Latin America)",
    "Spanish (Mexico)",
    "Spanish (Spain)",
    "Spanish (United States)",
    "Sundanese",
    "Swahili",
    "Swedish",
    "Tajik",
    "Tamil",
    "Tatar",
    "Telugu",
    "Thai",
    "Tigrinya",
    "Tongan",
    "Turkish",
    "Turkmen",
    "Twi",
    "Ukrainian",
    "Urdu",
    "Uyghur",
    "Uzbek",
    "Vietnamese",
    "Walloon",
    "Welsh",
    "Western Frisian",
    "Xhosa",
    "Yiddish",
    "Yoruba",
    "Zulu"
  ];

  // src/utils/ui.ts
  var defaultFontFamily = "S\xF6hne,ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif,Helvetica Neue,Arial,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji";

  // src/components/promptEdit.tsx
  function PromptBox(props) {
    const [prompt, setPrompt] = h2(props.prompt);
    const isDefault = prompt.id === "default";
    const isSelected = props.selected;
    function toggleVisibility() {
      const updatedPrompt = {
        ...prompt,
        showOnToolbar: !prompt.showOnToolbar
      };
      setPrompt(updatedPrompt);
      persistPrompt(updatedPrompt);
    }
    __name(toggleVisibility, "toggleVisibility");
    p2(() => {
      setPrompt(props.prompt);
    }, [props.prompt]);
    function deletePrompt() {
      if (window.confirm("Are you sure you want to delete this prompt?")) {
        props.onDelete(prompt.id);
      }
    }
    __name(deletePrompt, "deletePrompt");
    return /* @__PURE__ */ o2("div", { className: "flex flex-col gap-2 text-gray-100 text-sm", children: /* @__PURE__ */ o2("a", { className: isSelected ? "flex py-3 px-3 items-center gap-3 relative rounded-md cursor-pointer break-all pr-14 bg-gray-800 hover:bg-gray-800 group" : "flex py-3 px-3 items-center gap-3 relative rounded-md hover:bg-[#2A2B32] pr-14 cursor-pointer break-all group", title: prompt.body, onClick: (event) => props.onClick(event, prompt.id), children: [
      /* @__PURE__ */ o2("div", { class: "text-white", children: /* @__PURE__ */ o2(svg_default.instruction, {}) }),
      /* @__PURE__ */ o2("div", { className: "flex-1 text-ellipsis max-h-5 overflow-hidden break-all relative", style: { zIndex: 520 }, children: [
        prompt.name,
        /* @__PURE__ */ o2("div", { className: isSelected ? "absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-gray-800" : "absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-gray-900 group-hover:from-[#2A2B32]", style: { zIndex: 525 } })
      ] }),
      !isDefault && /* @__PURE__ */ o2("div", { className: "absolute flex right-1 text-gray-300", style: { zIndex: 530 }, children: [
        /* @__PURE__ */ o2("button", { title: "Toggle visibility on toolbar", className: "hover:text-white p-1", onClick: toggleVisibility, children: prompt.showOnToolbar ? /* @__PURE__ */ o2(svg_default.visible, {}) : /* @__PURE__ */ o2(svg_default.invisible, {}) }),
        /* @__PURE__ */ o2("button", { title: "Delete this prompt", className: "hover:text-white p-1", onClick: deletePrompt, children: /* @__PURE__ */ o2(svg_default.trashcan, {}) })
      ] })
    ] }) });
  }
  __name(PromptBox, "PromptBox");
  function PromptList(props) {
    const selectedPrompt = props.selectedPrompt;
    const setSelectedPrompt = props.setSelectedPrompt;
    const promptList = props.promptList;
    const setPromptList = props.setPromptList;
    p2(() => {
      persistPromptSetting({ cppSelectedPromptID: selectedPrompt });
    }, [selectedPrompt]);
    function newPrompt() {
      const template = getPromptTemplate();
      const id = template.id;
      const updatedPromptList = {
        ...promptList,
        [id]: template
      };
      setPromptList(updatedPromptList);
      persistPromptList(updatedPromptList);
      setSelectedPrompt(id);
    }
    __name(newPrompt, "newPrompt");
    async function onDeletPrompt(id) {
      const record = await destroyPrompt(id);
      setSelectedPrompt("default");
      setPromptList(record);
    }
    __name(onDeletPrompt, "onDeletPrompt");
    function onClickPrompt(_4, id) {
      setSelectedPrompt(id);
    }
    __name(onClickPrompt, "onClickPrompt");
    return /* @__PURE__ */ o2("nav", { className: "flex h-full flex-col space-y-1 p-2 bg-gray-900", style: { width: "16rem" }, children: [
      /* @__PURE__ */ o2("div", { className: "flex-col flex-1 overflow-y-auto overscroll-none border-b border-white/20 h-full", children: Object.values(promptList).sort(sortBytimeCreated).map(
        (prompt) => /* @__PURE__ */ o2(PromptBox, { prompt, selected: prompt.id === selectedPrompt, onClick: onClickPrompt, onDelete: onDeletPrompt }, prompt.id)
      ) }),
      /* @__PURE__ */ o2(
        "a",
        {
          onClick: newPrompt,
          className: "flex py-3 px-3 items-center gap-3 rounded-md hover:bg-gray-500/10 transition-colors duration-200 text-white cursor-pointer text-sm mb-2 flex-shrink-0 border border-white/20",
          children: [
            /* @__PURE__ */ o2(svg_default.plusMark, {}),
            "New prompt"
          ]
        }
      )
    ] });
  }
  __name(PromptList, "PromptList");
  function PromptForm(props) {
    const [isDefault, setIsDefault] = h2(false);
    const [name, setName] = h2(defaultPrompt.name);
    const [body, setBody] = h2(defaultPrompt.body);
    const [pattern, setPattern] = h2(defaultPrompt.pattern);
    const [advanced, setAdvanced] = h2(false);
    const [resolvedPattern, setResolvedPattern] = h2("");
    document.querySelector("#cpp-dialog-root")?.style.display == "none";
    p2(() => {
      async function updatePrompt() {
        const prompt = props.promptList[props.selectedPrompt];
        setName(prompt.name);
        setBody(prompt.body);
        setPattern(prompt.pattern);
        setIsDefault(prompt.id === "default");
        setResolvedPattern(await resolvePattern(prompt));
      }
      __name(updatePrompt, "updatePrompt");
      updatePrompt();
    }, [props.selectedPrompt, props.promptList, props.isDialogOpen]);
    function persist(prompt) {
      const updatedPromptList = {
        ...props.promptList,
        [prompt.id]: prompt
      };
      persistPromptList(updatedPromptList);
      props.setPromptList(updatedPromptList);
    }
    __name(persist, "persist");
    function autoSave(e3, key) {
      if (!e3.target)
        return;
      const updatedPrompt = {
        ...props.promptList[props.selectedPrompt],
        [key]: e3.target.value
      };
      persist(updatedPrompt);
    }
    __name(autoSave, "autoSave");
    async function updateBody(e3) {
      const body2 = e3.target.value;
      setBody(body2);
      const promptDirty = {
        ...props.promptList[props.selectedPrompt],
        body: body2
      };
      setResolvedPattern(await resolvePattern(promptDirty));
    }
    __name(updateBody, "updateBody");
    async function updatePattern(e3) {
      const pattern2 = e3.target.value;
      setPattern(pattern2);
      const promptDirty = {
        ...props.promptList[props.selectedPrompt],
        pattern: pattern2
      };
      setResolvedPattern(await resolvePattern(promptDirty));
    }
    __name(updatePattern, "updatePattern");
    async function resetPattern() {
      const updatedPrompt = {
        ...props.promptList[props.selectedPrompt],
        pattern: defaultPrompt.pattern
      };
      setPattern(defaultPrompt.pattern);
      setResolvedPattern(await resolvePattern(updatedPrompt));
      persist(updatedPrompt);
    }
    __name(resetPattern, "resetPattern");
    function toggleAdvanced() {
      setAdvanced(!advanced);
    }
    __name(toggleAdvanced, "toggleAdvanced");
    const containerWidthInPx = 640;
    const splittedResolved = resolvedPattern.split(keywords.message);
    return /* @__PURE__ */ o2(_, { children: /* @__PURE__ */ o2("div", { className: "relative h-full w-full transition-width flex flex-col items-stretch flex-1", children: [
      /* @__PURE__ */ o2("div", { className: "flex overflow-y-auto overscroll-none h-full flex-col items-center text-sm dark:bg-gray-800", style: { width: `${containerWidthInPx}px` }, children: [
        /* @__PURE__ */ o2("div", { className: "group w-full text-gray-800 dark:text-gray-100 border-b border-black/10 dark:border-gray-900/50 dark:bg-gray-800", children: /* @__PURE__ */ o2("div", { className: "text-base gap-4 md:gap-6 md:max-w-2xl lg:max-w-xl xl:max-w-3xl p-4 md:py-6 flex lg:px-0 m-auto justify-center", children: /* @__PURE__ */ o2("div", { className: "relative flex", style: { width: `${containerWidthInPx - 95}px` }, children: [
          /* @__PURE__ */ o2("div", { className: "flex items-center justify-center mr-2", style: "width: 100px", children: /* @__PURE__ */ o2("span", { children: "Prompt name" }) }),
          /* @__PURE__ */ o2(
            "input",
            {
              type: "text",
              placeholder: isDefault ? "Default prompt" : "Enter a prompt name",
              class: "w-full rounded-md dark:bg-gray-800 dark:focus:border-white dark:focus:ring-white",
              style: { height: "44px", width: `${containerWidthInPx - 220}px` },
              tabIndex: 1,
              disabled: isDefault,
              value: name,
              onBlur: (event) => autoSave(event, "name")
            }
          )
        ] }) }) }),
        /* @__PURE__ */ o2("div", { className: "group w-full text-gray-800 dark:text-gray-100 border-b border-black/10 dark:border-gray-900/50 bg-gray-50 dark:bg-[#444654]", children: /* @__PURE__ */ o2("div", { className: "text-base gap-4 md:gap-6 md:max-w-2xl lg:max-w-xl xl:max-w-3xl p-4 md:py-6 flex lg:px-0 m-auto justify-center", children: /* @__PURE__ */ o2("div", { className: "relative flex flex-col", style: { width: `${containerWidthInPx - 95}px` }, children: [
          /* @__PURE__ */ o2("div", { className: "flex items-center", children: [
            /* @__PURE__ */ o2(svg_default.instruction, {}),
            /* @__PURE__ */ o2("span", { className: "ml-2", children: "Prompt" })
          ] }),
          /* @__PURE__ */ o2(
            "textarea",
            {
              placeholder: isDefault ? "Default has no instruction" : "Enter an instruction",
              class: "w-full rounded-md dark:bg-gray-800 dark:focus:border-white dark:focus:ring-white text-sm disabled:text-gray-300 disabled:italic",
              style: { height: "96px", overflowY: "hidden", fontStyle: isDefault ? "italic" : "normal" },
              tabIndex: 2,
              disabled: isDefault,
              value: body,
              onInput: updateBody,
              onBlur: (event) => autoSave(event, "body")
            }
          ),
          /* @__PURE__ */ o2("button", { className: "relative ", onClick: toggleAdvanced, children: /* @__PURE__ */ o2("div", { className: "flex absolute justify-center items-center right-0", children: [
            advanced ? /* @__PURE__ */ o2(svg_default.arrowUp, {}) : /* @__PURE__ */ o2(svg_default.arrowDown, {}),
            /* @__PURE__ */ o2("span", { className: "text-gray-300 hover:text-white", children: "Advnaced prompt" })
          ] }) }),
          advanced && /* @__PURE__ */ o2(_, { children: [
            /* @__PURE__ */ o2("div", { className: "mt-6" }),
            /* @__PURE__ */ o2("div", { className: "flex items-center", children: [
              /* @__PURE__ */ o2(svg_default.gears, {}),
              /* @__PURE__ */ o2("span", { className: "ml-2", children: "Pattern" })
            ] }),
            /* @__PURE__ */ o2(
              "textarea",
              {
                placeholder: isDefault ? "(Default prompt is empty)" : "You can restore the default pattern by the button below.",
                class: "w-full rounded-md dark:bg-gray-800 dark:focus:border-white dark:focus:ring-white text-sm disabled:text-gray-300 disabled:italic",
                style: { height: "112px", overflowY: "hidden", fontStyle: isDefault ? "italic" : "normal" },
                tabIndex: 3,
                disabled: isDefault,
                value: pattern,
                onInput: updatePattern,
                onBlur: (event) => autoSave(event, "pattern")
              }
            ),
            !isDefault && /* @__PURE__ */ o2("button", { className: "p-1", disabled: isDefault, onClick: resetPattern, children: /* @__PURE__ */ o2("div", { className: "flex w-full items-center justify-center text-sm", children: [
              /* @__PURE__ */ o2(svg_default.restore, {}),
              /* @__PURE__ */ o2("span", { className: "pl-1", children: "back to default" })
            ] }) }),
            /* @__PURE__ */ o2("div", { className: "flex items-center mt-2", children: [
              /* @__PURE__ */ o2(svg_default.preview, {}),
              /* @__PURE__ */ o2("span", { className: "ml-2", children: "Preview" })
            ] }),
            /* @__PURE__ */ o2("div", { className: "p-1 border-b border-black/10 dark:border-gray-900/50 dark:focus:ring-white rounded-md dark:bg-gray-800", children: /* @__PURE__ */ o2("pre", { className: "text-sm text-gray-300", style: { height: "136px", overflowY: "hidden", whiteSpace: "pre-wrap" }, children: splittedResolved.map((str, i3) => /* @__PURE__ */ o2(_, { children: [
              /* @__PURE__ */ o2("span", { style: { fontFamily: defaultFontFamily }, children: str }),
              i3 < splittedResolved.length - 1 && /* @__PURE__ */ o2("span", { style: { fontStyle: "italic", textDecoration: "underline" }, children: "Your message on chat" })
            ] })) }) })
          ] })
        ] }) }) }),
        /* @__PURE__ */ o2("div", { className: "w-full flex-shrink-0", style: "height: 4rem" })
      ] }),
      /* @__PURE__ */ o2("div", { className: "absolute w-full bottom-0 left-0 dark:bg-gray-800", style: "height: 4rem", children: /* @__PURE__ */ o2("div", { className: "flex w-full h-full items-center", children: /* @__PURE__ */ o2("a", { class: "btn relative btn-neutral ml-2", href: "https://prompts.chat/", target: "_blank", rel: "noopener noreferrer", children: [
        /* @__PURE__ */ o2(svg_default.community, {}),
        /* @__PURE__ */ o2("div", { class: "flex w-full items-center justify-center gap-2", children: "Community prompts" })
      ] }) }) })
    ] }) });
  }
  __name(PromptForm, "PromptForm");
  function PromptEdit(props) {
    const defaultClassName = "flex overflow-hidden relative";
    const ContainerClassName = `${defaultClassName} ${props.ContainerClassName ? props.ContainerClassName : ""}`;
    const defaultContainerStyle = {};
    const ContainerStyle = Object.assign({}, defaultContainerStyle, props.ContainerStyle ? props.ContainerStyle : {});
    const [selectedPrompt, setSelectedPrompt] = h2(defaultPromptSetting.cppSelectedPromptID);
    const [promptList, setPromptList] = h2({ default: defaultPrompt });
    const [isDialogOpen, setDialogOpen] = h2(true);
    function updateSetting() {
      readPromptSetting().then((setting) => {
        setSelectedPrompt(setting.cppSelectedPromptID);
      });
    }
    __name(updateSetting, "updateSetting");
    p2(() => {
      readPromptList().then((list) => {
        if (Object.keys(list).length === 0)
          return;
        setPromptList(list);
      });
      updateSetting();
      const dialogRoot = document.querySelector("#cpp-dialog-root");
      let observer2;
      if (dialogRoot) {
        observer2 = new MutationObserver((mutationsList) => {
          for (const mutation of mutationsList) {
            if (mutation.type === "attributes" && mutation.attributeName === "style") {
              setDialogOpen(dialogRoot.style.display !== "none");
            }
          }
        });
        observer2.observe(dialogRoot, { attributes: true });
      }
      return () => {
        observer2.disconnect();
      };
    }, []);
    p2(() => {
      updateSetting();
    }, [isDialogOpen]);
    return /* @__PURE__ */ o2("div", { className: ContainerClassName, style: ContainerStyle, children: /* @__PURE__ */ o2("div", { className: "relative flex h-full max-w-full", children: [
      /* @__PURE__ */ o2(PromptList, { selectedPrompt, setSelectedPrompt, promptList, setPromptList }),
      /* @__PURE__ */ o2(PromptForm, { selectedPrompt, promptList, setPromptList, isDialogOpen })
    ] }) });
  }
  __name(PromptEdit, "PromptEdit");

  // src/components/toolbar.tsx
  function getBoxClassName() {
    return "flex border border-black/10 dark:border-gray-900/50 dark:text-white bg-white dark:bg-gray-700 rounded-md shadow-[0_0_10px_rgba(0,0,0,0.10)] dark:shadow-[0_0_15px_rgba(0,0,0,0.10)]";
  }
  __name(getBoxClassName, "getBoxClassName");
  function HoverElement() {
    return /* @__PURE__ */ o2("div", { className: `p-1 border border-black/10 dark:border-gray-900/50 rounded-md`, children: /* @__PURE__ */ o2(svg_default.questionMark, {}) });
  }
  __name(HoverElement, "HoverElement");
  function PropertyLabel(props) {
    return /* @__PURE__ */ o2("div", { className: "flex items-center text-gray-900 dark:text-gray-300", children: /* @__PURE__ */ o2("span", { children: props.title }) });
  }
  __name(PropertyLabel, "PropertyLabel");
  function DescriptionBox(props) {
    return /* @__PURE__ */ o2(BooleanProvider, { children: /* @__PURE__ */ o2(hoverBox_default, { hoverElement: /* @__PURE__ */ o2(HoverElement, {}), children: /* @__PURE__ */ o2("div", { className: `${getBoxClassName()} absolute p-2 z-50`, style: { top: "8px", width: "20rem", transform: "translate(0, -100%)" }, children: /* @__PURE__ */ o2("span", { className: "text-sm select-none", children: props.description }) }) }) });
  }
  __name(DescriptionBox, "DescriptionBox");
  function SettingBox(props) {
    const innerText = /* @__PURE__ */ __name(() => /* @__PURE__ */ o2("span", { className: "text-ellipsis overflow-hidden", style: "white-space: nowrap;", children: props.toggleState.value ? props.bodyState.value : "\u274C" }), "innerText");
    return /* @__PURE__ */ o2(BooleanProvider, { children: [
      /* @__PURE__ */ o2(ConditionalPopup, { className: `${getBoxClassName()} absolute flex-col`, style: { width: "256px", transform: "translate(0, -100%)", top: "0" }, children: props.children }),
      /* @__PURE__ */ o2(ToggleButton, { innerText: innerText(), className: `cpp-${props.propertyName}-button grow ml-1` })
    ] });
  }
  __name(SettingBox, "SettingBox");
  function SliderSelection(props) {
    return /* @__PURE__ */ o2("div", { className: "flex", style: "flex-basis: 31%", children: [
      /* @__PURE__ */ o2(DescriptionBox, { description: props.description }),
      /* @__PURE__ */ o2(PropertyLabel, { title: props.propertyName }),
      /* @__PURE__ */ o2(SettingBox, { propertyName: props.propertyName, toggleState: props.toggleState, bodyState: props.bodyState, children: [
        /* @__PURE__ */ o2("div", { className: "flex justify-between w-full text-sm", children: [
          /* @__PURE__ */ o2(InputBox, { type: "checkbox", context: { value: props.toggleState.value, setValue: props.toggleState.setValue }, inputClassName: "ml-2", labelText: "Enabled" }),
          /* @__PURE__ */ o2(InputBox, { type: "number", min: props.min, max: props.max, step: props.inputStep, context: { value: props.bodyState.value, setValue: props.bodyState.setValue }, inputStyle: { width: props.widthInEm + 1 + "em" }, enabled: props.toggleState.value })
        ] }),
        /* @__PURE__ */ o2(Slider, { min: props.min, max: props.max, step: props.sliderStep, context: { value: props.bodyState.value, setValue: props.bodyState.setValue }, containerClassName: "px-2 pt-3 pb-1", enabled: props.toggleState.value, tickLabels: props.tickLabels })
      ] })
    ] });
  }
  __name(SliderSelection, "SliderSelection");
  function PromptDropdown() {
    const [isDialogOpen, setDialogOpen] = h2(false);
    const [options, setOptions] = h2([]);
    const [selectedPrompt, setSelectedPrompt] = h2(defaultPromptSetting.cppSelectedPromptID);
    async function readPersistent() {
      let selectedPrompt2;
      const setting = await readPromptSetting();
      selectedPrompt2 = setting.cppSelectedPromptID;
      setSelectedPrompt(selectedPrompt2);
      const list = await readPromptList();
      const filtered = Object.values(list).filter((prompt) => prompt.showOnToolbar || prompt.id == selectedPrompt2).sort(sortBytimeCreated).map((prompt) => {
        return { value: prompt.id, label: prompt.name };
      });
      if (filtered.length === 0)
        filtered.push({ value: "default", label: "Default" });
      setOptions(filtered);
    }
    __name(readPersistent, "readPersistent");
    p2(() => {
      readPersistent();
    }, [isDialogOpen]);
    function onChangePrompt(e3) {
      setSelectedPrompt(e3.target.value);
      persistPromptSetting({ cppSelectedPromptID: e3.target.value });
    }
    __name(onChangePrompt, "onChangePrompt");
    p2(() => {
      const dialogRoot = document.querySelector("#cpp-dialog-root");
      if (!dialogRoot)
        return;
      const observer2 = new MutationObserver((mutationsList) => {
        for (const mutation of mutationsList) {
          if (mutation.type === "attributes" && mutation.attributeName === "style") {
            setDialogOpen(dialogRoot.style.display !== "none");
          }
        }
      });
      observer2.observe(dialogRoot, { attributes: true });
      return () => {
        observer2.disconnect();
      };
    }, []);
    return /* @__PURE__ */ o2(Dropdown, { value: selectedPrompt, onChange: onChangePrompt, options, className: "py-1 mx-2 text-ellipsis", style: { width: "10rem" } });
  }
  __name(PromptDropdown, "PromptDropdown");
  function LanguageDropdown() {
    const [language, setLanguage] = h2(defaultUserConfig.cppLanguage);
    const [languageEnabled, setLanguageEnabled] = h2(defaultUserConfig.cppLanguageEnabled);
    const options = [];
    languages_list.forEach((v3) => {
      options.push({ value: v3, label: v3 });
    });
    p2(() => {
      getUserConfig().then((userConfig) => {
        setLanguage(userConfig.cppLanguage);
        setLanguageEnabled(userConfig.cppLanguageEnabled);
      });
    }, []);
    function onChangeLanguage(e3) {
      setLanguage(e3.target.value);
      saveUserConfig({ cppLanguage: e3.target.value });
    }
    __name(onChangeLanguage, "onChangeLanguage");
    function onChangeLanguageEnabled(e3) {
      setLanguageEnabled(e3.target.checked);
      saveUserConfig({ cppLanguageEnabled: e3.target.checked });
    }
    __name(onChangeLanguageEnabled, "onChangeLanguageEnabled");
    return /* @__PURE__ */ o2(SettingBox, { propertyName: "language", toggleState: { value: languageEnabled, setValue: setLanguageEnabled }, bodyState: { value: language, setValue: setLanguage }, children: /* @__PURE__ */ o2("div", { className: "flex w-full text-sm", style: "width: 20em", children: [
      /* @__PURE__ */ o2(InputBox, { type: "checkbox", context: { value: languageEnabled, setValue: setLanguageEnabled }, inputClassName: "ml-2", labelText: "Enabled", onChange: onChangeLanguageEnabled }),
      /* @__PURE__ */ o2(Dropdown, { value: language, onChange: onChangeLanguage, options, className: "py-1 mx-2 text-ellipsis", style: { width: "10rem" }, disabled: !languageEnabled })
    ] }) });
  }
  __name(LanguageDropdown, "LanguageDropdown");
  function Toolbar(props) {
    const isShow = useBoolean();
    const [temperature, setTemperature] = h2(defaultUserConfig.cppTemperature);
    const [temperatureEnabled, setTemperatureEnabled] = h2(defaultUserConfig.cppTemperatureEnabled);
    const [maxTokens, setMaxTokens] = h2(defaultUserConfig.cppMaxTokens);
    const [maxTokensEnabled, setMaxTokensEnabled] = h2(defaultUserConfig.cppMaxTokensEnabled);
    const [presencePenalty, setPresencePenalty] = h2(defaultUserConfig.cppPresencePenalty);
    const [presencePenaltyEnabled, setPresencePenaltyEnabled] = h2(defaultUserConfig.cppPresencePenaltyEnabled);
    const [frequencyPenalty, setFrequencyPenalty] = h2(defaultUserConfig.cppFrequencyPenalty);
    const [frequencyPenaltyEnabled, setFrequencyPenaltyEnabled] = h2(defaultUserConfig.cppFrequencyPenaltyEnabled);
    p2(() => {
      getUserConfig().then((userConfig) => {
        setTemperature(userConfig.cppTemperature);
        setTemperatureEnabled(userConfig.cppTemperatureEnabled);
        setMaxTokens(userConfig.cppMaxTokens);
        setMaxTokensEnabled(userConfig.cppMaxTokensEnabled);
        setPresencePenalty(userConfig.cppPresencePenalty);
        setPresencePenaltyEnabled(userConfig.cppPresencePenaltyEnabled);
        setFrequencyPenalty(userConfig.cppFrequencyPenalty);
        setFrequencyPenaltyEnabled(userConfig.cppFrequencyPenaltyEnabled);
      });
    }, []);
    p2(() => {
      saveUserConfig({
        cppTemperature: temperature,
        cppTemperatureEnabled: temperatureEnabled,
        cppMaxTokens: maxTokens,
        cppMaxTokensEnabled: maxTokensEnabled,
        cppPresencePenalty: presencePenalty,
        cppPresencePenaltyEnabled: presencePenaltyEnabled,
        cppFrequencyPenalty: frequencyPenalty,
        cppFrequencyPenaltyEnabled: frequencyPenaltyEnabled
      });
    }, [temperature, temperatureEnabled, maxTokens, maxTokensEnabled, presencePenalty, presencePenaltyEnabled, frequencyPenalty, frequencyPenaltyEnabled]);
    const defaultClass = `absolute ${getBoxClassName()} py-3 pl-2 cpp-toolbar`;
    const className = `${props?.className ? props.className : ""} ${defaultClass}`;
    const defaultStyle = { display: isShow.bool ? "flex" : "none", flexWrap: "wrap" };
    const style = Object.assign({}, defaultStyle, props?.style);
    return /* @__PURE__ */ o2("div", { style, className, children: [
      /* @__PURE__ */ o2(
        SliderSelection,
        {
          propertyName: "temperature",
          description: "Controls the randomness or creativity of the generated text. The higher value will make the model generate more diverse and creative. The lower will generate more focused and conservative text.",
          bodyState: { value: temperature, setValue: setTemperature },
          toggleState: { value: temperatureEnabled, setValue: setTemperatureEnabled },
          widthInEm: 2,
          min: 0,
          max: 2,
          inputStep: 0.01,
          sliderStep: 0.05,
          tickLabels: ["Precise", "Balanced", "Creative"]
        }
      ),
      /* @__PURE__ */ o2(
        SliderSelection,
        {
          propertyName: "max_tokens",
          description: "The maximum number of tokens that the model can handle in a single input-output sequence. Note that this limit includes both input and output tokens. So very long inputs might lead to incomplete or cut-off outputs due to the token limit constraint.",
          bodyState: { value: maxTokens, setValue: setMaxTokens },
          toggleState: { value: maxTokensEnabled, setValue: setMaxTokensEnabled },
          widthInEm: 3,
          min: 1,
          max: 4096,
          inputStep: 1,
          sliderStep: 1,
          tickLabels: ["1", "4096"]
        }
      ),
      /* @__PURE__ */ o2("div", { className: "flex", style: "flex-basis: 31%", children: [
        /* @__PURE__ */ o2(
          DescriptionBox,
          {
            description: "Prompt is a piece of text or input provided to the model to guide its response or output. Well-crafted prompt can generate answer more clear, relevant, efficient. ChatGPT++ offers the access to well-known prompts repositry, Awesome ChatGPT Prompts."
          }
        ),
        /* @__PURE__ */ o2(PropertyLabel, { title: "prompt" }),
        /* @__PURE__ */ o2(PromptDropdown, {}),
        /* @__PURE__ */ o2(
          CppDialog,
          {
            buttonText: /* @__PURE__ */ o2("div", { className: "text-gray-300 hover:text-white", children: /* @__PURE__ */ o2(svg_default.modification, {}) }),
            namespace: "prompt-edit",
            title: "Edit prompts",
            children: /* @__PURE__ */ o2(PromptEdit, { ContainerStyle: { height: "30rem" } })
          }
        )
      ] }),
      /* @__PURE__ */ o2(
        SliderSelection,
        {
          propertyName: "presence_penalty",
          description: "{{{Add description here}}}",
          bodyState: { value: presencePenalty, setValue: setPresencePenalty },
          toggleState: { value: presencePenaltyEnabled, setValue: setPresencePenaltyEnabled },
          widthInEm: 2,
          min: -2,
          max: 2,
          inputStep: 0.01,
          sliderStep: 0.1,
          tickLabels: ["-2.0", "0.0", "2.0"]
        }
      ),
      /* @__PURE__ */ o2(
        SliderSelection,
        {
          propertyName: "frequency_penalty",
          description: "{{{Add description here}}}",
          bodyState: { value: frequencyPenalty, setValue: setFrequencyPenalty },
          toggleState: { value: frequencyPenaltyEnabled, setValue: setFrequencyPenaltyEnabled },
          widthInEm: 2,
          min: -2,
          max: 2,
          inputStep: 0.01,
          sliderStep: 0.1,
          tickLabels: ["-2.0", "0.0", "2.0"]
        }
      ),
      /* @__PURE__ */ o2("div", { className: "flex", style: "flex-basis: 31%", children: [
        /* @__PURE__ */ o2(
          DescriptionBox,
          {
            description: "{{{Add description here}}}"
          }
        ),
        /* @__PURE__ */ o2(PropertyLabel, { title: "language" }),
        /* @__PURE__ */ o2(LanguageDropdown, {})
      ] }),
      /* @__PURE__ */ o2("button", { onClick: () => testRemoveSyncedStorage("cppPrompt"), children: "REMOVE(TEST)" })
    ] });
  }
  __name(Toolbar, "Toolbar");

  // src/scripts/main.tsx
  async function applyPrompt(textarea) {
    const message = textarea.value;
    if (!message.trim())
      return;
    const promptSetting = await readPromptSetting();
    const selected = promptSetting.cppSelectedPromptID;
    const prompt = await readPrompt(selected);
    if (!prompt)
      return;
    const resolvedPattern = await resolvePattern(prompt, message);
    textarea.value = resolvedPattern;
  }
  __name(applyPrompt, "applyPrompt");
  async function patch() {
    const chatgptTextarea = document.querySelector("div#__next textarea");
    const chatgptSubmit = chatgptTextarea?.parentNode?.querySelector("button");
    const chatgptForm = document.querySelector("form");
    const chatgptFormHolder = chatgptForm?.parentElement;
    const inputContainer = chatgptTextarea?.parentElement;
    if (!chatgptTextarea || !chatgptSubmit || !inputContainer || !chatgptForm || !chatgptFormHolder)
      return;
    chatgptTextarea.classList.add("chatgpt-textarea");
    chatgptSubmit.classList.add("chatgpt-submit");
    const toolbarButtonWidth = 28;
    function submit() {
      if (!chatgptTextarea || !chatgptTextarea.value.trim())
        return;
      chatgptTextarea.focus();
      const e3 = new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        ctrlKey: true,
        bubbles: true
      });
      chatgptTextarea.dispatchEvent(e3);
    }
    __name(submit, "submit");
    chatgptTextarea.addEventListener("keydown", async function(e3) {
      if (e3.key !== "Enter" || e3.shiftKey || e3.ctrlKey)
        return;
      e3.preventDefault();
      e3.stopImmediatePropagation();
      await applyPrompt(chatgptTextarea);
      submit();
    }, { capture: true });
    chatgptSubmit.addEventListener("click", async function(e3) {
      e3.stopImmediatePropagation();
      await applyPrompt(chatgptTextarea);
      submit();
    }, { capture: true });
    const buttonContainer = document.createElement("div");
    function positionToolbarButton(buttonContainer2, e3) {
      if (!chatgptForm)
        return;
      const formRect = chatgptForm.getBoundingClientRect();
      const buttonXPos = formRect.right - toolbarButtonWidth - 38;
      buttonContainer2.style.width = `${toolbarButtonWidth}px`;
      buttonContainer2.style.left = `${buttonXPos}px`;
    }
    __name(positionToolbarButton, "positionToolbarButton");
    chatgptFormHolder.appendChild(buttonContainer);
    positionToolbarButton(buttonContainer);
    window.addEventListener("resize", (_4) => positionToolbarButton(buttonContainer));
    buttonContainer.classList.value = "flex fixed text-gray-500 items-center";
    buttonContainer.style.right = "486px";
    buttonContainer.style.bottom = "63px";
    const toolbarWidth = window.getComputedStyle(inputContainer).width;
    const toolbarLeft = -Number(toolbarWidth.replace("px", "")) + toolbarButtonWidth + 38 + "px";
    const toolbarButton = /* @__PURE__ */ o2(BooleanProvider, { children: [
      /* @__PURE__ */ o2(Toolbar, { style: { top: "-14px", width: toolbarWidth, left: toolbarLeft, transform: "translate(0, -100%)" } }),
      /* @__PURE__ */ o2(ToggleButton, { innerText: /* @__PURE__ */ o2(svg_default.settings, {}), style: { width: toolbarButtonWidth + "px", height: "24px", fontSize: "10pt" }, className: "cpp-toolbar-button" })
    ] });
    B(toolbarButton, buttonContainer);
  }
  __name(patch, "patch");
  var observer;
  window.onload = function() {
    const chatgptRoot = document.querySelector("main")?.parentElement?.parentElement;
    if (!chatgptRoot)
      return;
    patch();
    observer = new MutationObserver(
      () => {
        try {
          patch();
        } catch (e3) {
          console.error(e3);
        }
      }
    );
    observer.observe(chatgptRoot, { childList: true });
  };
  window.onunload = () => observer?.disconnect();
})();
